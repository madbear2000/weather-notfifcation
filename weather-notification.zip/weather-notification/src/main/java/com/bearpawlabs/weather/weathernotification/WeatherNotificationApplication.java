package com.bearpawlabs.weather.weathernotification;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WeatherNotificationApplication {

	public static void main(String[] args) {
		SpringApplication.run(WeatherNotificationApplication.class, args);
	}
}
